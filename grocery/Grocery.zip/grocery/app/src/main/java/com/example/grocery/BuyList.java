package com.example.grocery;

import android.app.Dialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import static com.example.grocery.Main2Activity.sqLiteHelper;

public class BuyList extends AppCompatActivity {

    ArrayList<Buy> buylist;
    BuyAdapter adapter = null;
    ListView listbuyview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_list);
        listbuyview = (ListView) findViewById(R.id.buylist);
        buylist = new ArrayList<>();
        adapter = new BuyAdapter(this, R.layout.activity_buy_view, buylist);
        listbuyview.setAdapter(adapter);
        Cursor cursor = sqLiteHelper.getData("SELECT * FROM paycarts");
        buylist.clear();


        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String usname = cursor.getString(1);
            String usemail = cursor.getString(2);
            String usaddress = cursor.getString(3);
            String usphone = cursor.getString(4);
            String cash = cursor.getString(5);
            String cashmode = cursor.getString(6);
            String demail = cursor.getString(6);

            String status = cursor.getString(7);


            buylist.add(new Buy(usname, usemail, usaddress, usphone, cash, cashmode,demail,status, id));
        }

        adapter.notifyDataSetChanged();

    }

}
