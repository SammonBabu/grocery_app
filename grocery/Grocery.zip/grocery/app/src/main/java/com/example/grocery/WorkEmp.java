package com.example.grocery;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import static com.example.grocery.Main2Activity.sqLiteHelper;

public class WorkEmp extends AppCompatActivity {
    // public static SQLiteHelper sqLiteHelper;
   TextView txtweemail,txtweusername,txtweadd,txtwephne,txtwecash,txtwecashmode,txtwedemail,txtwestatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workemp);
        txtweemail = findViewById(R.id.txtweemail);
        txtweusername = findViewById(R.id.txtweusername);

        txtweadd = findViewById(R.id.txtweadd);
        txtwephne = findViewById(R.id.txtwephne);
        txtwecash = findViewById(R.id.txtwecash);

        txtwecashmode = findViewById(R.id.txtwecashmode);

        txtwedemail = findViewById(R.id.txtwedemail);

        txtwestatus = findViewById(R.id.txtwestatus);



        String e = getIntent().getStringExtra("EMAIL");
        txtweemail.setText(e);
        String n = getIntent().getStringExtra("name");
        txtweusername.setText(n);

        String a = getIntent().getStringExtra("address");
        txtweadd.setText(a);

        String p = getIntent().getStringExtra("phone");
        txtwephne.setText(p);
        String c = getIntent().getStringExtra("cash");
        txtwecash.setText(c);

        String cm = getIntent().getStringExtra("cashmode");
        txtwecashmode.setText(cm);
        String d = getIntent().getStringExtra("demail");
        txtwedemail.setText(d);

        String s = getIntent().getStringExtra("status");
        txtwestatus.setText(s);







    }


}
