package com.example.grocery;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;

import androidx.appcompat.app.AppCompatActivity;

import static com.example.grocery.Main2Activity.sqLiteHelper;

public class WorkAssign extends AppCompatActivity {
    // public static SQLiteHelper sqLiteHelper;
TextView txtwuser,txtwemail,txtwadd,txtwphne,txtwcash,txtwcashmode,txtwstatus,txtwdemail;
    Buy buy;
   Button btnass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work);

     //   final EditText edarea = findViewById(R.id.txtwuser);
       // edarea.setText(buy.get());

       // imageView = findViewById(R.id.imageView);
        txtwuser = findViewById(R.id.txtwuser);
        txtwemail = findViewById(R.id.txtwemail);
        txtwadd = findViewById(R.id.txtwadd);
        txtwphne = findViewById(R.id.txtwphne);
        txtwcash = findViewById(R.id.txtwcash);
        txtwcashmode = findViewById(R.id.txtwcashmode);
     //   txtwcashmode = findViewById(R.id.txtwcashmode);
        txtwstatus = findViewById(R.id.txtwstatus);

        txtwdemail = findViewById(R.id.txtwdemail);



       Intent intent = getIntent();
       if(intent.getExtras() != null){
            buy = (Buy) intent.getSerializableExtra("items");
            //imageView.setImageResource(buy.getImages());
            txtwuser.setText(buy.getUsname());
           txtwemail.setText(buy.getUsemail());
           txtwadd.setText(buy.getUsaddress());
           txtwphne.setText(buy.getUsphone());
           txtwcash.setText(buy.getCash());
           txtwcashmode.setText(buy.getCashmode());
           txtwstatus.setText(buy.getStatus());





       }
        btnass = findViewById(R.id.btnass);


        btnass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("main activity", "item clicked");
                // startActivity(new Intent(BinAdapter.this,Binupdate.class).putExtra("items",  mDisplayedValues.get(position)));
                Intent dd = (new Intent( getApplicationContext(),WorkEmp.class));
                dd.putExtra("name",txtwuser.getText().toString().trim());
                dd.putExtra("EMAIL",txtwemail.getText().toString().trim());
                dd.putExtra("address",txtwadd.getText().toString().trim());
                dd.putExtra("phone",txtwphne.getText().toString().trim());
                dd.putExtra("cash",txtwcash.getText().toString().trim());
                dd.putExtra("cashmode",txtwcashmode.getText().toString().trim());
                dd.putExtra("demail",txtwdemail.getText().toString().trim());

                dd.putExtra("status",txtwstatus.getText().toString().trim());


                startActivity(dd);







            }


        });




    }


}
