package com.example.grocery;

public class Setting {
}
