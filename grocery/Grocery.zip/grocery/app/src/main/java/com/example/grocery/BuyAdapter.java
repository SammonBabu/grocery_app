package com.example.grocery;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class BuyAdapter extends BaseAdapter {
    //   public static SQLiteHelper sqLiteHelper;

    private Context context;
    private  int layout;
    private ArrayList<Buy> blist;


    public BuyAdapter(Context context, int layout, ArrayList<Buy> blist) {
        this.context = context;
        this.layout = layout;
        this.blist = blist;
    }



    @Override
    public int getCount() {
        return blist.size();
    }

    @Override
    public Object getItem(int position) {
        return blist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{

        TextView txtvusername,txtvmail,txtvaddress,txtphone,txtcash,txtcashmode,txtvstatus;
      EditText  txtdrlmail;
      Spinner spinnerStatus;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {

        View row = view;
        BuyAdapter.ViewHolder holder = new BuyAdapter.ViewHolder();

        if(row == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            //  LayoutInflater inflater = LayoutInflater.from(mCtx);
            row = inflater.inflate(layout, null);

            holder.txtvusername = (TextView) row.findViewById(R.id.txtvusername);
            holder.txtvmail = (TextView) row.findViewById(R.id.txtvmail);
            holder.txtvaddress = (TextView) row.findViewById(R.id.txtvaddress);
            holder.txtphone = (TextView) row.findViewById(R.id.txtphone);
            holder.txtcash = (TextView) row.findViewById(R.id.txtcash);
            holder.txtcashmode = (TextView) row.findViewById(R.id.  txtcashmode);
            holder.spinnerStatus = (Spinner) row.findViewById(R.id.  spinnerStatus);
            holder.txtvstatus = (TextView) row.findViewById(R.id.  txtvstatus);

            // holder. txtTotalcart = (TextView) row.findViewById(R.id.txtTotalcart);
            row.setTag(holder);
        }
        else {
            holder = (BuyAdapter.ViewHolder) row.getTag();
        }

        final Buy buy = blist.get(position);

        holder.txtvusername.setText(buy.getUsname());
        holder.txtvmail.setText(buy.getUsemail());
        holder.txtvaddress.setText(buy.getUsaddress());
        holder.txtphone.setText(buy.getUsphone());
        holder.txtcash.setText(buy.getCash());

        holder.txtcashmode.setText(buy.getCashmode());
        holder.txtvstatus.setText(buy.getStatus());

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("main activity", "item clicked");
                // startActivity(new Intent(BinAdapter.this,Binupdate.class).putExtra("items",  mDisplayedValues.get(position)));
                Intent dd = (new Intent( context.getApplicationContext(),WorkAssign.class).putExtra("items",  blist.get(position)));
                  context.startActivity(dd);

                //  int id;

              //  updateb(bin,position);
            }


        });

        //  holder.txtTotalcart.setText(foodcart.getTotalprice());
        // holder.txtPrice.setText(String.valueOf(food.getPrice()));
        return row;


        //TextView txtTotalcart = view.findViewById(R.id.txtTotalcart)
    }
}
