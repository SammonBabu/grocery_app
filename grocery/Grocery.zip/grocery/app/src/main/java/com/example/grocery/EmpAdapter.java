package com.example.grocery;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class EmpAdapter extends BaseAdapter {
    //   public static SQLiteHelper sqLiteHelper;

    private Context context;
    private  int layout;
    private ArrayList<Employee> elist;


    public EmpAdapter(Context context, int layout, ArrayList<Employee> elist) {
        this.context = context;
        this.layout = layout;
        this.elist = elist;
    }



    @Override
    public int getCount() {
        return elist.size();
    }

    @Override
    public Object getItem(int position) {
        return elist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{

        TextView txtEmpName,txtEmpEmail,txtEmpPassword,txtEmpMobile,txtEmpAddress;

    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        View row = view;
        EmpAdapter.ViewHolder holder = new EmpAdapter.ViewHolder();

        if(row == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            //  LayoutInflater inflater = LayoutInflater.from(mCtx);
            row = inflater.inflate(layout, null);

            holder.txtEmpName = (TextView) row.findViewById(R.id.textViewName);
            holder.txtEmpEmail = (TextView) row.findViewById(R.id.textViewEmpEmail);
            holder.txtEmpPassword = (TextView) row.findViewById(R.id.textEmpPassword);
            holder.txtEmpMobile = (TextView) row.findViewById(R.id.textViewEmpMobile);
            holder.txtEmpAddress = (TextView) row.findViewById(R.id.textViewEmpAddress);

            // holder. txtTotalcart = (TextView) row.findViewById(R.id.txtTotalcart);
            row.setTag(holder);
        }
        else {
            holder = (EmpAdapter.ViewHolder) row.getTag();
        }

        final Employee employee = elist.get(position);

       holder.txtEmpName.setText(employee.getEmpname());
        holder.txtEmpEmail.setText(employee.getEmpemail());
        holder.txtEmpPassword.setText(employee.getEmppassword());
        holder.txtEmpMobile.setText(employee.getEmpmobile());
        holder.txtEmpAddress.setText(employee.getEmpaddress());

        //  holder.txtTotalcart.setText(foodcart.getTotalprice());
        // holder.txtPrice.setText(String.valueOf(food.getPrice()));
        return row;


        //TextView txtTotalcart = view.findViewById(R.id.txtTotalcart)
    }
}
